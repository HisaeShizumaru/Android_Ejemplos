/** Automatically generated file. DO NOT MODIFY */
package com.game.primerjuego;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}